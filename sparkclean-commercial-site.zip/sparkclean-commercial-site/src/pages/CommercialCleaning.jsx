import React, { useState } from "react";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { CheckCircle, PhoneCall, Mail, Building2 } from "lucide-react";

const features = [
  "Office Cleaning",
  "Retail & Storefront Services",
  "Janitorial Contracts",
  "Carpet & Floor Care",
  "Post-Construction Cleanup",
  "Eco-Friendly Products"
];

export default function CommercialCleaning() {
  const [quoteData, setQuoteData] = useState({ name: '', email: '', service: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setQuoteData({ ...quoteData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Quote submitted:", quoteData);
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Header */}
      <header className="bg-gray-900 text-white p-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
          <h1 className="text-3xl font-bold">SparkClean Commercial Services</h1>
          <div className="mt-4 md:mt-0">
            <Button className="bg-white text-gray-900 font-semibold">Get a Quote</Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="p-8 max-w-7xl mx-auto grid gap-8 md:grid-cols-2 items-center">
        <div>
          <h2 className="text-4xl font-bold mb-4">Your Workplace. Spotless.</h2>
          <p className="mb-6 text-lg">
            At SparkClean, we specialize in top-tier commercial cleaning tailored to offices,
            retail spaces, and industrial environments. Our fully trained professionals deliver
            consistent, quality results using eco-conscious methods.
          </p>
          <Button className="bg-gray-900 text-white">Book a Free Walkthrough</Button>
        </div>
        <img
          src="/images/cleaning-team.jpg"
          alt="Professional cleaners at work"
          className="rounded-2xl shadow-lg"
        />
      </section>

      {/* Services Section */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto text-center mb-12">
          <h3 className="text-3xl font-semibold">Our Services</h3>
          <p className="text-gray-600 mt-2">Trusted solutions tailored to your commercial space</p>
        </div>
        <div className="grid gap-6 md:grid-cols-3 px-8 max-w-7xl mx-auto">
          {features.map((feature, idx) => (
            <Card key={idx} className="shadow-md">
              <CardContent className="p-6 flex items-start gap-4">
                <CheckCircle className="text-green-600 mt-1" />
                <span className="font-medium text-gray-800">{feature}</span>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Why Choose Us + Contact Info */}
      <section className="py-16 px-8 bg-white max-w-7xl mx-auto grid md:grid-cols-2 gap-12">
        <div>
          <h4 className="text-2xl font-semibold mb-4">Why Choose SparkClean?</h4>
          <ul className="space-y-3 text-gray-700">
            <li>✓ Fully insured and bonded professionals</li>
            <li>✓ Flexible schedules that fit your needs</li>
            <li>✓ 24/7 customer support</li>
            <li>✓ Satisfaction guaranteed</li>
          </ul>
        </div>
        <div className="bg-gray-100 p-6 rounded-xl shadow-md">
          <h5 className="text-lg font-semibold mb-4">Contact Us</h5>
          <div className="flex items-center gap-3 mb-3">
            <PhoneCall className="text-gray-700" />
            <span>(281) 749-0347</span>
          </div>
          <div className="flex items-center gap-3 mb-3">
            <Mail className="text-gray-700" />
            <span>contact@sparkcleanpro.com</span>
          </div>
          <div className="flex items-center gap-3">
            <Building2 className="text-gray-700" />
            <span>123 Commerce St, Suite 400, Metro City</span>
          </div>
        </div>
      </section>

      {/* Quote Request Form */}
      <section className="py-16 px-8 bg-gray-50">
        <div className="max-w-3xl mx-auto">
          <h3 className="text-2xl font-semibold mb-6 text-center">Request a Free Quote</h3>
          {submitted ? (
            <div className="text-center text-green-600 font-medium">
              Thank you! Your request has been submitted.
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                value={quoteData.name}
                onChange={handleChange}
                required
                className="w-full p-3 border rounded-lg"
              />
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                value={quoteData.email}
                onChange={handleChange}
                required
                className="w-full p-3 border rounded-lg"
              />
              <input
                type="text"
                name="service"
                placeholder="Service Needed"
                value={quoteData.service}
                onChange={handleChange}
                required
                className="w-full p-3 border rounded-lg"
              />
              <textarea
                name="message"
                placeholder="Additional Details"
                value={quoteData.message}
                onChange={handleChange}
                rows={4}
                className="w-full p-3 border rounded-lg"
              />
              <Button type="submit" className="bg-gray-900 text-white w-full">
                Submit Request
              </Button>
            </form>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white text-center py-6">
        <p>&copy; {new Date().getFullYear()} SparkClean Commercial Services. All rights reserved.</p>
      </footer>
    </div>
  );
}
